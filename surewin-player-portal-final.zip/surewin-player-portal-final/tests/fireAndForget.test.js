import test from 'node:test'
import assert from 'node:assert/strict'
import { fireAndForget } from '../src/lib/fireAndForget.js'

test('fireAndForget handles a rejected thenable without unhandled rejection', async () => {
  let unhandled = false
  const onUnhandled = () => { unhandled = true }
  process.once('unhandledRejection', onUnhandled)
  const thenable = { then(resolve, reject) { queueMicrotask(() => reject(new Error('expected rejection'))); return undefined } }
  fireAndForget(thenable)
  await new Promise(resolve => setTimeout(resolve, 10))
  process.removeListener('unhandledRejection', onUnhandled)
  assert.equal(unhandled, false)
})

import fs from 'node:fs'

test('Dashboard and Rewards do not call catch directly on Supabase RPC builders', () => {
  for (const file of ['Dashboard.jsx', 'Rewards.jsx']) {
    const source = fs.readFileSync(new URL(`../src/pages/${file}`, import.meta.url), 'utf8')
    assert.match(source, /fireAndForget\(\s*supabase\.rpc\(/s)
    assert.doesNotMatch(source, /supabase\s*\.rpc\([^\n]*\)\s*\n?\s*\.catch\(/)
  }
})
