import fs from 'node:fs'
const source = fs.readFileSync(new URL('../src/pages/Dashboard.jsx', import.meta.url), 'utf8')
if (!source.includes("new Set(['unlocked', 'claimed', 'issued', 'paid', 'approved'])")) {
  throw new Error('Dashboard must define explicit unlocked player-level statuses')
}
if (!source.includes('UNLOCKED_LEVEL_STATUSES.has(pl.status)')) {
  throw new Error('Dashboard must not count in_progress player levels as completed')
}
console.log('PASS: dashboard completion status guard')
