import test from 'node:test'
import assert from 'node:assert/strict'
import { buildCampaignGuide } from '../src/lib/campaignGuide.js'

test('campaign guide explains how to complete each configured reward level', () => {
  const guide = buildCampaignGuide({
    campaign: {
      start_date: '2026-08-29',
      end_date: '2026-08-31',
      offer_desc: 'Deposit cumulatively during the campaign period.\nRewards are subject to verification.',
    },
    levels: [
      { level_order: 1, level_name: 'Bronze — RM31K', deposit_threshold: 31000, reward_amount: 1388, reward_type: 'credit', description: 'Reach RM31,000 cumulative deposit.' },
      { level_order: 2, level_name: 'Silver — RM80K', deposit_threshold: 80000, reward_amount: 3888, reward_type: 'credit', description: 'Reach RM80,000 cumulative deposit.' },
    ],
  })

  assert.equal(guide.steps.length, 4)
  assert.match(guide.steps[0], /Join/i)
  assert.match(guide.steps[1], /deposit/i)
  assert.match(guide.steps[2], /Bronze.*RM31,000.*RM1,388/i)
  assert.match(guide.steps[2], /Silver.*RM80,000.*RM3,888/i)
  assert.match(guide.rules, /Deposit cumulatively/)
})

test('campaign guide falls back cleanly when no campaign rules text exists', () => {
  const guide = buildCampaignGuide({ campaign: {}, levels: [] })

  assert.equal(guide.rules, '')
  assert.equal(guide.steps.length, 4)
  assert.match(guide.steps[0], /campaign/i)
  assert.match(guide.steps[1], /deposit/i)
})
