import { strict as assert } from 'node:assert'
import { buildRewardView } from '../src/lib/rewardViewModel.js'

const rewards = [
  { id: 'r2', campaign_level_id: 'silver', campaign_player_level_id: 'pl2', reward_amount: 3888, status: 'pending' },
  { id: 'r1', campaign_level_id: 'bronze', campaign_player_level_id: 'pl1', reward_amount: 1388, status: 'pending' },
  { id: 'r3', campaign_level_id: 'locked', campaign_player_level_id: 'pl3', reward_amount: 6888, status: 'pending' },
]
const levels = [
  { id: 'silver', campaign_id: 'camp1', level_order: 2, level_name: 'Silver — RM80K', reward_type: 'credit' },
  { id: 'bronze', campaign_id: 'camp1', level_order: 1, level_name: 'Bronze — RM31K', reward_type: 'credit' },
  { id: 'locked', campaign_id: 'camp1', level_order: 3, level_name: 'Gold — RM169K', reward_type: 'credit' },
]
const playerLevels = [
  { id: 'pl1', campaign_level_id: 'bronze', status: 'unlocked', unlocked_at: '2026-08-29T10:00:00Z' },
  { id: 'pl2', campaign_level_id: 'silver', status: 'unlocked', unlocked_at: '2026-08-29T11:00:00Z' },
  { id: 'pl3', campaign_level_id: 'locked', status: 'in_progress', unlocked_at: null },
]
const campaigns = [{ id: 'camp1', campaign_name: 'Merdeka 2026 Deposit Reward', status: 'active' }]

const view = buildRewardView({ rewards, levels, playerLevels, campaigns })

assert.equal(view.counts.Pending, 2)
assert.equal(view.filtered.Pending.length, 2)
assert.equal(view.groups.length, 1)
assert.equal(view.groups[0].items.length, 2)
assert.equal(view.groups[0].campaign.id, 'camp1')
assert.equal(view.playerLevelMap.pl1.status, 'unlocked')
assert.equal(view.rewards.some(r => r.id === 'r3'), false)
console.log('PASS: Rewards pending records remain visible and grouped by campaign')
