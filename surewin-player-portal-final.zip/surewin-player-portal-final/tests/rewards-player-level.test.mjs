import fs from 'node:fs'
const source = fs.readFileSync(new URL('../src/pages/Rewards.jsx', import.meta.url), 'utf8')
if (!source.includes('playerLevel={pl}')) throw new Error('RewardCard must receive the resolved player level row')
if (!source.includes('playerLevel?.unlocked_at')) throw new Error('RewardCard must use playerLevel for unlock date')
if (/!reward\.paid_at && pl\?\./.test(source)) throw new Error('Rewards must not reference undefined pl inside RewardCard')
console.log('PASS: Rewards uses playerLevel instead of undefined pl')
