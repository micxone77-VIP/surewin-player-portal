import fs from 'node:fs'

const source = fs.readFileSync(new URL('../src/pages/Dashboard.jsx', import.meta.url), 'utf8')

if (/from\(['"]campaign_levels['"]\)/.test(source)) {
  throw new Error('SECURITY REGRESSION: Dashboard must not query campaign_levels directly')
}
if (!/rpc\(['"]get_my_campaign_levels['"]/.test(source)) {
  throw new Error('SECURITY REGRESSION: Dashboard must use get_my_campaign_levels RPC for level metadata')
}
if (/nextLevel\.level_code/.test(source)) {
  throw new Error('SECURITY REGRESSION: Dashboard renders nextLevel.level_code')
}
console.log('PASS: Dashboard uses player-scoped level metadata RPC and never requests/renders level_code')
