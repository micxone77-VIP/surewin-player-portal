# SureWin Player Portal deployment

This version fixes the Home dashboard reward display so reward amounts are always exact (e.g. RM1,388, RM3,888, RM6,888) instead of compact K/M notation.

From the project root:

```cmd
npm install
npm run build
npx wrangler pages deploy dist --project-name surewin-player-portal
```

After deployment, hard refresh the browser with Ctrl+Shift+R.

Do not deploy this Portal build to the CRM project `swcrmv3`.
