from pathlib import Path

# Dashboard
p = Path("src/pages/Dashboard.jsx")
s = p.read_text(encoding="utf-8")

s = s.replace(
    "                ??&nbsp;",
    "                \\u{1F4C5}&nbsp;",
    1
)

s = s.replace(
    "<span style={{ fontSize: '2rem' }}>??</span>",
    "<span style={{ fontSize: '2rem' }}>\\u{1F3C6}</span>",
    1
)

s = s.replace(
    "                  ??&nbsp;{fmtRM(nextLevel.reward_amount)}",
    "                  \\u{1F4B0}&nbsp;{fmtRM(nextLevel.reward_amount)}",
    1
)

s = s.replace(
    "                  ??&nbsp;{fmtRM(prog.reward_amount)} reward",
    "                  \\u{1F4B0}&nbsp;{fmtRM(prog.reward_amount)} reward",
    1
)

s = s.replace(
    "<div style={styles.emptyIcon}>??</div>",
    "<div style={styles.emptyIcon}>\\u{1F4ED}</div>",
    1
)

p.write_text(s, encoding="utf-8")


# CampaignDetail
p = Path("src/pages/CampaignDetail.jsx")
s = p.read_text(encoding="utf-8")

s = s.replace(
    '<span style={styles.youAreHerePin}>??</span>',
    '<span style={styles.youAreHerePin}>\\u{1F4CD}</span>',
    1
)

s = s.replace(
    '<span>??</span>',
    '<span>\\u{1F680}</span>',
    1
)

s = s.replace(
    "function TrophyIcon()      { return <span style={{ fontSize: '2.5rem' }}>??</span> }",
    "function TrophyIcon()      { return <span style={{ fontSize: '2.5rem' }}>\\u{1F3C6}</span> }",
    1
)

s = s.replace(
    "function HourglassIcon()   { return <span>?</span> }",
    "function HourglassIcon()   { return <span>\\u{23F3}</span> }",
    1
)

s = s.replace(
    "Start your journey ï¿½ make your first deposit",
    "Start your journey — make your first deposit",
    1
)

p.write_text(s, encoding="utf-8")

print("Icon repair complete.")