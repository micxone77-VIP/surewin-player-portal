from pathlib import Path
files=list(Path("src").rglob("*.js"))+list(Path("src").rglob("*.jsx"))
for f in files:
 s=f.read_text(encoding="utf-8")
 s=s.replace("emoji: '??', color: '#a78bfa'", "emoji: '\\u{1F48E}', color: '#a78bfa'")
 s=s.replace("emoji: '??', color: '#60a5fa'", "emoji: '\\u{1F4A0}', color: '#60a5fa'")
 s=s.replace("emoji: '?', color: '#f59e0b'", "emoji: '\\u{2B50}', color: '#f59e0b'")
 s=s.replace("emoji: '??', color: '#94a3b8'", "emoji: '\\u{1F948}', color: '#94a3b8'")
 s=s.replace("emoji: '??', color: '#cd7f32'", "emoji: '\\u{1F949}', color: '#cd7f32'")
 s=s.replace("emoji: '?', color: '#e5e7eb'", "emoji: '\\u{1F525}', color: '#e5e7eb'")
 f.write_text(s,encoding="utf-8")
print("tier emoji repair complete")
